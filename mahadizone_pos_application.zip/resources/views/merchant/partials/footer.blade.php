<footer class="main-footer">
    <div class="pull-right hidden-xs">

    </div>
    <strong>  &copy; 2020 <a href="https://sufilifestyle.com">sufilifestyle</a>.</strong> All rights
    reserved.
  </footer>

  <div class="control-sidebar-bg"></div>
