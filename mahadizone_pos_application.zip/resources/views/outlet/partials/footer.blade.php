<footer class="main-footer">
    <div class="pull-right hidden-xs">

    </div>
    <strong>  &copy; 2022 <a href="">outlet</a>.</strong> All rights
    reserved.
  </footer>

  <div class="control-sidebar-bg"></div>
