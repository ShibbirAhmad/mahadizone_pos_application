<template>
   <div>
    
   </div>
</template>

<script>
export default {
    mounted(){
        console.log('hjkh')
    }
}
</script>

