<template>
  <div>
    <loading
      :active.sync="isLoading"
      :can-cancel="true"
      :is-full-page="fullPage"
    ></loading>

    <frontend-header></frontend-header>
    <div class="row">
      <div style="background-color: #eee" class="container-fluid">
        <div class="container box shadow">
          <div class="col-lg-12 bg-white" style="padding: 10px">
            <div class="card" style="border: 1px solid lightgrey">
              <div class="col-md-4" style="padding: 20px">
                <img class="card-img-top feature_image" :src="'/public/images/CEO.jpg'" />
              </div>
              <div class="card-body" style="padding: 10px">
                <h4 class="card-title" style="margin-bottom: 10px">
                  Online Shopping Bangladesh
                </h4>
                <p
                  class="card-text"
                  style="
                    text-align: justify;
                    line-height: 28px;
                    padding: 5px;
                    font-size: 16px;
                  "
                >
                  Online Shopping in Bangladesh Do you want to do online shopping in
                  Bangladesh? Oh ! who doesn't.Because of online shopping hassle-free of
                  traffic jam, time wasting, and so many other problem. In the USA there
                  are 60-79% of people buy their products online. You have not gone so
                  far, if you look India you see many people of India buy their products
                  from online. And online shopping become too popular day by day in
                  Bangladesh Now you think, If that's good, why many people don’t buy from
                  online in Bangladesh ? I really appreciate with you. Because Many people
                  don’t know about online shopping and also there is some problem with
                  online shopping in Bangladesh. I will try to give answer your question.
                  In this content, I will show you, , 1.The history of online shopping in
                  bangladesh 2. The reason why should you buy products from online 3.How
                  you can buy products from online 4.The source of eCommerce Product in
                  Bangladesh 5. The major problem of online shopping 6.The safety of
                  online shopping 7.Top e-commerce sites of Bangladesh 8.The present
                  condition of online shopping in Bangladesh So why you are waiting ,
                  let’s start: 1. History of Online shopping in Bangladesh : Everyone know
                  online shopping is many popular in a country like USA,UK or any other
                  European country. And they start their e-commerce journey many before.
                  But it’s should be a question to your minds or many others, How and when
                  e-commerce or online shopping comes in Bangladesh ? Which is the first
                  e-commerce company in Bangladesh ? are they still alive or not? OK! I am
                  breaking your curiosity.
                </p>

                <p
                  style="
                    text-align: justify;
                    line-height: 28px;
                    padding: 5px;
                    font-size: 16px;
                    margin-top: 20px;
                  "
                >
                  Let’s go to the flashback, It was 1999 when the first e-commerce company
                  comes in Bangladesh And Munshiji.com is the first e-commerce company in
                  bangladesh. that was not too much easy to start online shopping business
                  in bangladesh . It was not welcomed in Bangladesh at the beginning
                  stage. And Due to politics, slow internet, and poverty of our country
                  and others so many problems they stop their business in bd. After that
                  many companies have tried so many times but could not see the bright
                  sun. Though many people don’t know about Munshiji.com but they know
                  about ekhanei.com is first online shop in bangladesh. So,let’s discuss
                  when bangladeshi people started to know about online shopping . It was
                  2006 when ekhanei.com officially published by grameenphone and at the
                  same time they open cellbazar. And for the first time, It was a
                  successful project. And it’s open the eye of the investor. And many
                  investors inspire from them. And If we go to the flashback then we find
                  that It was the turning point to open the eye of investor and highly
                  inspire others to come in this sector. And after that Here comes Bikroy
                  and totally change the mind setup and widely give a good sound to people
                  to engage with the online marketplace. Though online shopping in
                  Bangladesh was not popular and not welcomed at the beginning stage it’s
                  come with many upwards and downwards in bd. And took about one and a
                  half decades to get success to come to today’s stage. And now many
                  companies like ajkerdeal,daraj and gearboost are come to the stage and
                  make easier shopping for people. 2. 10 reason for online shopping in
                  bangladesh Though there are so many reason to do online shopping in
                  bangladesh.But I will show you most 10 important reason that attract you
                  to do online shopping at bangladesh. So,let’s start : 1. Unbearable
                  Traffic Jam : If you live in Dhaka city then you will agree with me
                  that, the traffic jam of Dhaka city is totally out of control from you.
                  Because the road of Dhaka city is limited and many times VIP person go
                  on the road. And then start non-stop traffic. If your time is so much
                  important and you want to save your valuable time and not want the
                  hassle of traffic jam then online shopping is the best alternative
                  solution for you. 2. Get rid of product price bargains : If you have
                  experience of shopping in Dhaka city or anywhere of Bangladesh then you
                  will appreciate with me that, If you want to buy products from shopping
                  mall and not want to be foolish then you must bargain about product
                  price with the shopkeeper. Because, If you visit then you see the
                  majority of shopping mall in Bangladesh, the product price is not fixed.
                  And If you are a new customer then the shopkeeper will try to make you
                  foolish. And want to take two multiple prices to you from the real
                  price. So, If you buy products from online then you don’t need to
                  bargains with the shopkeeper.because the price of online products are
                  fixed. 3. Get rid of shopkeeper Bad behaviour : Though maximum
                  shopkeeper behavior is good. But there are some shopkeeper who will show
                  a bad attitude to you if you pricing the product but not buy from him
                  with any reason. An example, at new market in Dhaka there is a market
                  called Chandrima super market. Here a lady was hassled with language by
                  the shopkeeper. And then the police arrest the shopkeeper. And that news
                  came in many newspapers at that time. You may check.
                </p>

                <p
                  style="
                    text-align: justify;
                    line-height: 28px;
                    padding: 5px;
                    font-size: 16px;
                    margin-top: 30px;
                  "
                >
                  So, If you do your shopping online then you have not any risk or tension
                  about this matter.because in online shopping system you will not connect
                  with shopkeeper directly. And if you have any complaint about the
                  products or shopkeeper then you can do it with your website helpline
                  where you buy the products. And then they will take action on the
                  shopkeeper. 4. Product refund : If you buy a product from any physical
                  shopping mall and then if any product has any problem but the shopkeeper
                  hide it to you and you found that after come into your house then what
                  will you do? Obviously, you must go back to shopkeeper.but most of the
                  cases if the shopkeeper is not an honest person, he will not refund your
                  product anymore. And will say you, why not you see that before buying.
                  And they not refund product after buy. Though there have some shop who
                  have 7 or 10 or 15days refund policy. but the majority have not yet. On
                  the other hand, if you buy products from online and find the problem of
                  products or the products is not the same as you saw then you will get
                  chances to refund it with 3days. And almost every online shopping
                  company have the refund policy. 5. Varieties of price waste your Time :
                  Suppose you want to buy a shirt or dress and one shopkeeper tell you the
                  price is $15 and other says it $10. But the shirt color is the same but
                  you think the Cloth Threads are different. Or you buy a shirt or dress
                  and visit too many shops and getting confused about what should buy or
                  what not! And it’s really wastage of many people including me also in
                  the psychical shop. So, If you won't get rid of confusion and save your
                  time then online shopping in Bangladesh is the best option for you.
                  6.All of your products in one shop : Do you want to buy a t-shirt, a
                  watch, a cricket bat and also a frying pan?If yes, and from psychical
                  shopping mall then you must go to four shops. And you find one is market
                  ‘A’ and other is marke ‘B’ and others are market ‘C’ then what will you
                  do? You must go everywhere if you want to buy. But in the online
                  shopping at Bangladesh you don’t need to go to many shops.You will get
                  all of your products in one place, just add to cart your every product
                  and buy it in one click. And it will save you many times and make simple
                  to your life 7.The risk of political strike : Suppose you are ready for
                  your shopping and comes in the road from your house and see that today
                  is one kind of strike and the busses are stopped for this. And you can’t
                  go there or go to the market with extra bus fare and risk. And also it
                  wastes your many valuable time. On the other hand, if you buy your
                  products from online shopping of Bangladesh then you don’t take any
                  headache about this. 8.Is market close or Open : If you live in the
                  Dhaka city or anywhere in Bangladesh then you know that every market has
                  a specific different holiday.
                </p>

                <p
                  style="
                    text-align: justify;
                    line-height: 28px;
                    padding: 5px;
                    font-size: 16px;
                    margin-top: 30px;
                  "
                >
                  An example Eastern Plaza, Bashundhara City, New Market are closed on
                  Tuesday but mirpur 1 market closed in Thursday and Mirpur 10 or IDB of
                  agargaon are closed in Sunday. So, If you target one market and go on
                  there on the closed days and you will get back with Bare hands and waste
                  your money and time. Besides, The online shopping of Bangladesh Are open
                  for you 24hours of a day 7days of a weak and 365days of a year. When
                  your mind wants,what your mind want you can check the price of the
                  product and buy it in your preferred time. So, you are welcome in the
                  online shopping to Bangladesh. 9.Payment system and safety :If you don’t
                  have any car. You always going shopping without your personal vehicle, I
                  think the majority of us have not a personal car yet. Then you have a
                  risk of loss of your money bag or handset on the bus or other vehicles
                  in Dhaka city. And if you looked that the online shopping Bangladesh
                  system then you will find that, if you buy a product then you can pay it
                  from your mobile bank account or cash on delivery(that means pay after
                  getting your product). Where you have not to go anywhere and not have
                  any risk. You can pay with full of your safety. 10.online shopping in
                  bangladesh with home delivery: Do you think a product you see on your
                  monitor just order with a click and get it on your hand without any
                  hassle? Yes, the online shopping system makes true your dream. Now, You
                  don’t need to go on the market and don’t need to bear your products.
                  Your products will bear by someone and you will get it from your home
                  with online shopping Bangladesh home delivery System. Now, choice of
                  yours. Where you will shopping for your future shopping .please do
                  comment your Decision or thoughts about this? 3.How to buy from online
                  shopping in Bangladesh? Are you crazy about buying online shopping
                  Bangladesh clothes? If yes, then how? In this point, I will show you how
                  you can buy online shopping Bangladeshi dress from an online shop or
                  website. You have to just follow some step with me. You have to just
                  follow some step with me. 1.open account/sign up-in this step open
                  account with your email and verify your account with a verification
                  code.It’s easy like to open a Facebook ID. And also set a password to
                  your account 2.Login-just give your email and password to login.
                  3.choose a product -choose what you want to buy and add it to your add
                  to cart button. And then just click to buy button. It will take you on
                  the payment option page. 4.payment- if you have any coupon or discount
                  just place your coupon or discount and get low price of that product.
                  And here have 2 payment system ? Online payment : If you give your
                  payment with your bkash/rocket or master/visa card then it would be
                  online payment for you. And then a merchant of any e-commerce or online
                  shopping site will deliver your product risk free.many times it seems
                  that some product can be a very small number Marchent not want to send
                  you before payment .
                </p>

                <p
                  style="
                    text-align: justify;
                    line-height: 28px;
                    padding: 5px;
                    font-size: 16px;
                    margin-top: 30px;
                  "
                >
                  Then you need online payment.otherwise, you can buy any products with
                  cash on delivery. ? Cash on delivery : It’s a very interesting system
                  and the most popular system of online shopping in bangladesh or allover
                  in the world. And It’s a very simple and easy system The system is the
                  product come to your house with a delivery man and you check is it all
                  right as you saw then you pay to the delivery man. 4.The source of
                  eCommerce Product in Bangladesh : There was a time when the market was
                  in a low competition and then our majority products of online shopping
                  were from China .But now the time is change ,many local clients focus
                  their business in online shopping.Though lots of products still from
                  China. But for this reason of client competition now, many local
                  products come on online shopping in bangladesh. Like :online shopping
                  bangladesh dress online shopping bangladesh clothes,bd fashion online
                  and etc. And many other products you can find in Bangladesh now. So, You
                  are welcome in online shopping bangladesh. 5. The major problem of
                  online shopping : I think there is no service in the world without any
                  kinds of problem. And for the first of any service, there should be some
                  problem. And bangladesh is not out from those rules. And there has some
                  problem also. ? Product not delivery on right time: This is the most
                  common complaint of customer or almost 70-80% of the customer complaint
                  about this that the products deliver with delay 2-3 days or 7days delay
                  from their given timing. ? Real time tracking system : In bangladesh, No
                  e-commerce company still not start any real time tracking system where
                  the customer could ensure where their product is now? and how it is? Is
                  there any problem happened with my product? why so late ? all of the
                  questions could be answered if the real time tracking system open. And I
                  think it will open very soon . And it will be more popular. ? Wrong
                  product delivery : Sometimes by mistake, they deliver Wrong product to
                  the customer for their wrong packing and then customer get angry on them
                  and refund the products. And if the customer needs the product then he
                  again re-order to deliver the product. And It’s waste and gives a hassle
                  to the customer. ? Wrong address or information:Either some bad customer
                  to take an act of revenge or want to give some hassle to the delivery
                  man they don’t pick up their phone on product delivery time or when the
                  delivery man would go his house or neither given a wrong address to
                  delivery address. And for some that reason, the online shop got some
                  strict and not want to deliver with only a product. They deliver product
                  in one area with many customers.so that, if one or two customers given
                  wrong information but the maximum product will deliver on the right time
                  . And if we want to understand that , It’s also a reason for late
                  delivery of our product. 6.The safety of online shopping : It’s can be a
                  question to your mind . Am I safe with online shopping ? Is my data
                  secure ? or my online payment or bkash/rocket in a risk ? In the modern
                  hacking world it’s not impossible if you not aware of this. And the
                  safety of your accounts is on your hand. You can ask me how ? Yes now, I
                  tell you how can safe with that just simply follow only 1 rule. And that
                  is , when buying any online shop then just check that their website have
                  https:// version or not.
                </p>

                <p
                  style="
                    text-align: justify;
                    line-height: 28px;
                    padding: 5px;
                    font-size: 16px;
                    margin-top: 30px;
                  "
                >
                  If it’s on https:// or there have a locked button on there. Or if it
                  without https version that means you do not properly save with your
                  data. It can be a risk for you. So, I highly recommend you not to buy
                  anything without SSL or https:// version site. So, keep safe with your
                  account and stay happy with online shopping. 7.Top e-commerce sites of
                  Bangladesh: In some recent years there are many entrepreneurs want or
                  try to come in this field and the marker is going competitive. With some
                  big company like daraj,ajker deal there are also some new company whose
                  are trying to give their best service to hold the market. With market
                  analysis, I will give you a list of the Best 10 e-commerce site list.
                  The list could be changed with google ranking or with customer
                  satisfaction or some company service. Or there could be a revolution
                  with any new company. Just like facebook . No one imagines about this
                  that, there some company can come and compete with google or Microsoft.
                  And according to some source, It’s hearing that Amazon and aliexpress
                  will come in bangladesh and then the market will be more competitive .
                  And then everyone service will be more good to stay on the market. ?
                  AjkerDeal.com ? Daraj.com, ? Priyoshop.com ? Kaymu.com.bd ? Bagdoom.com
                  ? Chaldal.com ? Branoo.com ? Othoba.com ? BDSHOP.com ? Aarong.com In the
                  above list can be changed by their service or can be joined by a big
                  company. An example daraj include with Alibaba in bangladesh. So, If
                  amazon or the biggest company like Ali express,e-bay comes in bangladesh
                  and Ajker deal or any company add with them and start a joint venture
                  company that not be a surprisable matter And some new chanel said that,
                  Amazon will come in 2020 for invest in bangladesh. And this also a good
                  thing that our local biggest players are the focus on there and come on
                  this sector. 10.The present condition of online shopping in Bangladesh:
                  According to wikipedia in some recent survey shows that Bangladesh is
                  one of the Top emerging online market in the world.And it will be around
                  2 billion(BDT) markets place. And also shown that after updating the
                  e-commerce rules by the bangladesh government the e-commerce business
                  has become so much easier and popular in bangladesh. And other things is
                  that After coming 3G internet the online shopping industry are
                  significantly boosted. And Basically online electronic
                  shop,clothing,toiletries, gift item, family shop ,kitchen item etc are
                  sold very much from other product. And IT will be more good easier and
                  many facilities will include in online shopping in bangladesh.
                </p>

                <p
                  style="
                    text-align: justify;
                    line-height: 28px;
                    padding: 5px;
                    font-size: 16px;
                    margin-top: 30px;
                  "
                >
                  according to prothom alo in bangladesh around 1.5 to 2 million people
                  are shopped in online every year. And the market was increased by about
                  20%. And according to Bangladesh bank data, There around 1 million
                  customers are on the mobile banking system.and 100 crore money were
                  transaction by mobile bank accounts.And another survey of MetrixLab they
                  see the 1 billion customers used the product to their stocks. And the
                  money worth about 147 billion bangladeshi TK. A Bangladeshi newspaper
                  “The Independent” Was show that the Annual online shopping transactions
                  worth about 1,000 crores Tk. And Above all the survey was 2014. And In
                  2017 the online sale was 1400 crores BDT, 2018 the online sale was 2000
                  Crores BDT. So now think in 2019 and in the future what is the ratio ?
                  So, we can say that the online shopping future will be good as a bright
                  Sun. SO , why you are behind? Let’s start and discover a new era of
                  bangladesh
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <frontend-footer></frontend-footer>
  </div>
</template>
<script>
import Loading from "vue-loading-overlay";
import "vue-loading-overlay/dist/vue-loading.css";
export default {
  created() {
    setTimeout(() => {
      this.isLoading = false;
    }, 1000);
  },
  data() {
    return {
      isLoading: true,
      fullPage: true,
    };
  },
  components: {
    Loading,
  },
};
</script>

<style scoped>
.desc_info p {
  display: inline-block;
  padding: 5px;
  margin: 10px;
  font-size: 16px;
  line-height: 26px;
  padding-bottom: 5px;
}

.feature_image {
  width: 350px;
  margin-top: 18px;
  border: 3px dashed;
}

@media screen and (max-width: 350px) {
  .desc_info p {
    font-size: 12px;
    line-height: 24px;
    font-style: normal;
  }

  .feature_image {
    width: 230px;
    height: 160px;
    margin-top: 18px;
    border: 3px dashed;
  }
}
</style>
